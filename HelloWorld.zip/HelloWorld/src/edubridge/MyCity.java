package edubridge;

public class MyCity {

	public static void main(String[] args) {
		System.out.println("My city is Akola....");
		System.out.println("Edubridge pvt ltd");
		  System.out.println("   Welcome to java full stack Course");

	}

}
